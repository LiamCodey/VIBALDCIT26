# Vibal Calculator — DCIT 26 Laboratory 1

A responsive calculator website built with React and Tailwind CSS for **DCIT 26: Application Development and Emerging Technologies — Laboratory 1**.

## Requirements covered

- React components
- Tailwind CSS layout and responsive styling
- React state and event handling
- Calculator display
- Number buttons 0–9
- Addition, subtraction, multiplication, and division
- AC / clear functionality
- Equals button
- Decimal input and sign toggle
- Keyboard support
- Divide-by-zero error handling
- Recent calculation history
- Instructions / User Guide section
- Responsive, clean calculator layout

## Run locally

### 1. Install Node.js
Use a current LTS version of Node.js.

### 2. Install dependencies

```bash
npm install
```

### 3. Start the development server

```bash
npm run dev
```

Open the local URL shown by Vite, normally `http://localhost:5173`.

### 4. Test the production build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Create a GitHub repository and upload this project.
2. Go to Vercel and import the GitHub repository.
3. Vercel should detect Vite automatically.
4. Build command: `npm run build`
5. Output directory: `dist`
6. Deploy.

## Deploy to Netlify

1. Push the project to GitHub.
2. Import the repository into Netlify.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy.

## Suggested project submission name

`Vibal-DCIT26-Laboratory1`
