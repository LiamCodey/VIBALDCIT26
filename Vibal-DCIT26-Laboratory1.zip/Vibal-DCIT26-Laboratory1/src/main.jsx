import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'

const OPERATORS = ['+', '−', '×', '÷']
const MAX_DIGITS = 14

function formatNumber(value) {
  if (!Number.isFinite(value)) return 'Error'
  if (Object.is(value, -0)) return '0'
  const rounded = Number.parseFloat(value.toPrecision(12))
  return rounded.toLocaleString('en-US', { maximumFractionDigits: 10, useGrouping: false })
}

function calculate(a, operator, b) {
  const left = Number(a)
  const right = Number(b)
  if (!Number.isFinite(left) || !Number.isFinite(right)) return null
  switch (operator) {
    case '+': return left + right
    case '−': return left - right
    case '×': return left * right
    case '÷': return right === 0 ? null : left / right
    default: return right
  }
}

function Calculator() {
  const [display, setDisplay] = useState('0')
  const [firstValue, setFirstValue] = useState(null)
  const [operator, setOperator] = useState(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [error, setError] = useState('')
  const [justCalculated, setJustCalculated] = useState(false)
  const [history, setHistory] = useState([])

  const clear = useCallback(() => {
    setDisplay('0')
    setFirstValue(null)
    setOperator(null)
    setWaitingForOperand(false)
    setError('')
    setJustCalculated(false)
  }, [])

  const inputDigit = useCallback((digit) => {
    setError('')
    if (waitingForOperand || justCalculated) {
      setDisplay(digit)
      setWaitingForOperand(false)
      setJustCalculated(false)
      return
    }
    setDisplay((current) => {
      if (current === '0') return digit
      if (current.replace('-', '').replace('.', '').length >= MAX_DIGITS) return current
      return current + digit
    })
  }, [waitingForOperand, justCalculated])

  const inputDecimal = useCallback(() => {
    setError('')
    if (waitingForOperand || justCalculated) {
      setDisplay('0.')
      setWaitingForOperand(false)
      setJustCalculated(false)
      return
    }
    setDisplay((current) => current.includes('.') ? current : `${current}.`)
  }, [waitingForOperand, justCalculated])

  const toggleSign = useCallback(() => {
    setError('')
    setDisplay((current) => current === '0' ? current : current.startsWith('-') ? current.slice(1) : `-${current}`)
  }, [])

  const chooseOperator = useCallback((nextOperator) => {
    setError('')
    const inputValue = Number(display)
    if (!Number.isFinite(inputValue)) return

    if (operator && firstValue !== null && !waitingForOperand) {
      const result = calculate(firstValue, operator, inputValue)
      if (result === null) {
        setError('Cannot divide by zero')
        setDisplay('Error')
        setFirstValue(null)
        setOperator(null)
        setWaitingForOperand(true)
        return
      }
      setFirstValue(result)
      setDisplay(formatNumber(result))
    } else {
      setFirstValue(inputValue)
    }
    setOperator(nextOperator)
    setWaitingForOperand(true)
    setJustCalculated(false)
  }, [display, firstValue, operator, waitingForOperand])

  const equals = useCallback(() => {
    if (operator === null || firstValue === null || display === 'Error') return
    const secondValue = Number(display)
    const result = calculate(firstValue, operator, secondValue)
    const expression = `${formatNumber(firstValue)} ${operator} ${formatNumber(secondValue)}`

    if (result === null) {
      setError('Cannot divide by zero')
      setDisplay('Error')
      setHistory((items) => [{ expression, result: 'Error' }, ...items].slice(0, 5))
      setFirstValue(null)
      setOperator(null)
      setWaitingForOperand(true)
      return
    }

    const formatted = formatNumber(result)
    setDisplay(formatted)
    setHistory((items) => [{ expression, result: formatted }, ...items].slice(0, 5))
    setFirstValue(null)
    setOperator(null)
    setWaitingForOperand(false)
    setJustCalculated(true)
  }, [display, firstValue, operator])

  const backspace = useCallback(() => {
    setError('')
    setJustCalculated(false)
    setDisplay((current) => current.length <= 1 || current === 'Error' ? '0' : current.slice(0, -1))
  }, [])

  const handleKeyDown = useCallback((event) => {
    const { key } = event
    if (/^[0-9]$/.test(key)) inputDigit(key)
    else if (key === '.') inputDecimal()
    else if (key === '+') chooseOperator('+')
    else if (key === '-') chooseOperator('−')
    else if (key === '*') chooseOperator('×')
    else if (key === '/') { event.preventDefault(); chooseOperator('÷') }
    else if (key === 'Enter' || key === '=') equals()
    else if (key === 'Escape' || key.toLowerCase() === 'c') clear()
    else if (key === 'Backspace') backspace()
  }, [backspace, chooseOperator, clear, equals, inputDecimal, inputDigit])

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [handleKeyDown])

  const buttons = useMemo(() => [
    { label: 'AC', action: clear, kind: 'utility' },
    { label: '±', action: toggleSign, kind: 'utility' },
    { label: '⌫', action: backspace, kind: 'utility' },
    { label: '÷', action: () => chooseOperator('÷'), kind: 'operator' },
    { label: '7', action: () => inputDigit('7'), kind: 'number' },
    { label: '8', action: () => inputDigit('8'), kind: 'number' },
    { label: '9', action: () => inputDigit('9'), kind: 'number' },
    { label: '×', action: () => chooseOperator('×'), kind: 'operator' },
    { label: '4', action: () => inputDigit('4'), kind: 'number' },
    { label: '5', action: () => inputDigit('5'), kind: 'number' },
    { label: '6', action: () => inputDigit('6'), kind: 'number' },
    { label: '−', action: () => chooseOperator('−'), kind: 'operator' },
    { label: '1', action: () => inputDigit('1'), kind: 'number' },
    { label: '2', action: () => inputDigit('2'), kind: 'number' },
    { label: '3', action: () => inputDigit('3'), kind: 'number' },
    { label: '+', action: () => chooseOperator('+'), kind: 'operator' },
    { label: '0', action: () => inputDigit('0'), kind: 'number', wide: true },
    { label: '.', action: inputDecimal, kind: 'number' },
    { label: '=', action: equals, kind: 'equals' },
  ], [backspace, chooseOperator, clear, equals, inputDecimal, inputDigit, toggleSign])

  return (
    <section className="w-full max-w-md">
      <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-[#101010] shadow-2xl shadow-black/50">
        <div className="border-b border-white/10 px-5 pb-5 pt-5 sm:px-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-neutral-500">Calculator</p>
              <p className="mt-1 text-sm text-neutral-300">DCIT 26 • Laboratory 1</p>
            </div>
            <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-neutral-400">React</span>
          </div>

          <div className="flex min-h-32 flex-col justify-end rounded-2xl border border-white/10 bg-[#080808] p-5 text-right">
            <div className="mb-2 h-5 text-xs text-neutral-600">{operator && firstValue !== null ? `${formatNumber(firstValue)} ${operator}` : ''}</div>
            <div key={`${display}-${justCalculated}`} className="display-pop overflow-hidden text-4xl font-semibold tracking-tight text-white sm:text-5xl" aria-live="polite">
              {display}
            </div>
            {error && <div className="mt-2 text-xs font-medium text-neutral-400">{error}</div>}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-3 p-5 sm:p-6">
          {buttons.map((button) => (
            <button
              key={button.label}
              onClick={button.action}
              aria-label={button.label === 'AC' ? 'Clear calculator' : button.label}
              className={`h-16 rounded-2xl border text-xl font-semibold transition active:scale-95 sm:h-[68px] ${
                button.wide ? 'col-span-1' : ''
              } ${
                button.kind === 'number'
                  ? 'border-white/5 bg-[#1b1b1b] text-white hover:bg-[#242424]'
                  : button.kind === 'operator'
                    ? 'border-white/10 bg-white text-black hover:bg-neutral-200'
                    : button.kind === 'equals'
                      ? 'border-white bg-white text-black hover:bg-neutral-200'
                      : 'border-white/5 bg-[#292929] text-neutral-200 hover:bg-[#343434]'
              }`}
            >
              {button.label}
            </button>
          ))}
        </div>

        <div className="border-t border-white/10 px-5 pb-5 pt-4 sm:px-6">
          <div className="flex items-center justify-between text-[11px] text-neutral-500">
            <span>Keyboard supported</span>
            <span>0–9 · + − × ÷ · Enter</span>
          </div>
        </div>
      </div>

      {history.length > 0 && (
        <div className="mt-5 rounded-2xl border border-white/10 bg-[#101010] p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Recent calculations</h3>
            <button onClick={() => setHistory([])} className="text-xs text-neutral-500 hover:text-white">Clear</button>
          </div>
          <div className="space-y-2">
            {history.map((item, index) => (
              <div key={`${item.expression}-${index}`} className="flex justify-between gap-4 rounded-xl bg-white/[0.03] px-3 py-2 text-sm">
                <span className="text-neutral-500">{item.expression}</span>
                <span className="font-medium text-white">= {item.result}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  )
}

function Guide() {
  return (
    <section id="guide" className="w-full max-w-4xl rounded-[2rem] border border-white/10 bg-[#101010] p-6 sm:p-8">
      <div className="mb-7">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-neutral-500">Instructions / User Guide</p>
        <h2 className="mt-2 text-2xl font-semibold text-white sm:text-3xl">How to use the calculator</h2>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <GuideCard number="01" title="Enter numbers" text="Click the number buttons from 0–9, or type numbers using your keyboard." />
        <GuideCard number="02" title="Choose an operation" text="Select addition (+), subtraction (−), multiplication (×), or division (÷)." />
        <GuideCard number="03" title="Get your result" text="Enter the second number, then press = or the Enter key to calculate." />
        <GuideCard number="04" title="Reset or edit" text="Use AC to reset everything, ± to change the sign, or ⌫ to remove the last digit." />
      </div>
      <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
        <p className="text-sm font-semibold text-white">Supported operations</p>
        <p className="mt-1 text-sm leading-6 text-neutral-500">Addition, subtraction, multiplication, division, decimals, sign changes, keyboard input, and divide-by-zero error handling.</p>
      </div>
    </section>
  )
}

function GuideCard({ number, title, text }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
      <span className="text-xs font-bold tracking-widest text-neutral-600">{number}</span>
      <h3 className="mt-3 font-semibold text-white">{title}</h3>
      <p className="mt-1 text-sm leading-6 text-neutral-500">{text}</p>
    </div>
  )
}

function App() {
  return (
    <main className="min-h-screen bg-[#080808] px-4 py-8 text-white sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-8">
        <header className="w-full max-w-4xl text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-neutral-400">
            Cavite State University • Tanza Campus
          </div>
          <h1 className="text-3xl font-semibold tracking-tight sm:text-5xl">Vibal Calculator</h1>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-6 text-neutral-500 sm:text-base">A responsive calculator built with React, Tailwind CSS, React state, and event handling.</p>
        </header>

        <Calculator />
        <Guide />

        <footer className="pb-4 text-center text-xs text-neutral-600">
          <p>DCIT 26: Application Development and Emerging Technologies</p>
          <p className="mt-1">Laboratory 1 • First Semester, SY 2026–2027</p>
        </footer>
      </div>
    </main>
  )
}

createRoot(document.getElementById('root')).render(<App />)
